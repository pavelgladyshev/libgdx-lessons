import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.utils.ScreenUtils;

public class MyGame extends ApplicationAdapter {
    TextureAtlas atlas;
    TextureAtlas.AtlasRegion hacker;
    TextureAtlas.AtlasRegion police;
    SpriteBatch batch;
    OrthographicCamera camera;

    @Override
    public void create() {
        atlas = new TextureAtlas(Gdx.files.internal("sample.atlas"));
        hacker = atlas.findRegion("hacker");
        police = atlas.findRegion("police");
        batch = new SpriteBatch();
        camera = new OrthographicCamera();
    }

    @Override
    public void render() {
        ScreenUtils.clear(1.0f, 1.0f, 1.0f, 1.0f);
        camera.setToOrtho(false,Gdx.graphics.getWidth(),Gdx.graphics.getHeight());
        camera.update();
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        batch.draw(hacker,0,0);
        batch.draw(hacker,10,10);
        batch.draw(hacker,20,20);
        batch.draw(police,300,0);
        batch.end();
    }

    @Override
    public void dispose() {
        batch.dispose();
        atlas.dispose();
    }
}
