import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;

public class MyGame extends ApplicationAdapter {
    static final float FRAME_DURATION = 1/10.0f; // 10 frames per second
    TextureAtlas runningAtlas;
    Animation runningAnimation;
    float runnerX, runnerY, elapsedTime;
    SpriteBatch batch;
    OrthographicCamera camera;

    @Override
    public void create() {
        runningAtlas = new TextureAtlas(Gdx.files.internal("running.atlas"));
        Array<TextureAtlas.AtlasRegion> runningFrames = runningAtlas.findRegions("running");
        runningAnimation = new Animation(FRAME_DURATION, runningFrames, Animation.PlayMode.LOOP);
        runnerX = Gdx.graphics.getWidth() * 0.5f;
        runnerY = Gdx.graphics.getHeight() * 0.1f;
        elapsedTime = 0;
        batch = new SpriteBatch();
        camera = new OrthographicCamera();
    }

    @Override
    public void render() {
        ScreenUtils.clear(1.0f, 1.0f, 1.0f, 1.0f);
        elapsedTime = elapsedTime + Gdx.graphics.getDeltaTime();
        TextureRegion currentFrame = (TextureRegion) runningAnimation.getKeyFrame(elapsedTime);
        camera.setToOrtho(false,Gdx.graphics.getWidth(),Gdx.graphics.getHeight());
        camera.update();
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        batch.draw(currentFrame, runnerX, runnerY);
        batch.end();
    }

    @Override
    public void dispose() {
        batch.dispose();
        runningAtlas.dispose();
    }
}
