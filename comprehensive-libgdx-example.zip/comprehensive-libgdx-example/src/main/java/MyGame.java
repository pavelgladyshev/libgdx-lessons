import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.maps.MapLayer;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.MapObjects;
import com.badlogic.gdx.maps.tiled.*;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.utils.ScreenUtils;
import model.Gamepiece;

public class MyGame extends ApplicationAdapter {

    public final static int GAME_WIDTH = 1024;
    public final static int GAME_HEIGHT = 812;
    public final static String CLICK_AND_DRAG_MESSAGE = "Click and drag the gamepiece.";
    public final static String FLIP_OR_ROTATE_MESSAGE = "Press 'f' to flip, or 'r' to rotate the gamepiece.";

    SpriteBatch batch;
    OrthographicCamera camera;
    TiledMap tiledMap;
    MapObjects mapObjects;
    TiledMapRenderer mapRenderer;
    Skin skin;
    TextureRegion blackSquare;
    BitmapFont helvetique;
    String bannerText;
    float bannerX;
    float bannerY;
    Gamepiece gamepiece;
    GraphicalGamepiece graphicalGamepiece;

    @Override
    public void create() {
        batch = new SpriteBatch();
        camera = new OrthographicCamera();

        tiledMap = new TmxMapLoader().load("play.tmx");
        TiledMapImageLayer imageLayer = (TiledMapImageLayer) tiledMap.getLayers().get(0);
        TiledMapTileLayer tileLayer = (TiledMapTileLayer) tiledMap.getLayers().get(1);
        MapLayer objectLayer = tiledMap.getLayers().get(2);
        mapObjects = objectLayer.getObjects();
        mapRenderer = new OrthogonalTiledMapRenderer(tiledMap);

        skin = new Skin(Gdx.files.internal("myskin.json"));
        blackSquare = skin.getRegion("game_square_black");
        helvetique = skin.getFont("helvetique");
        bannerText = "";
        bannerX = 10.0f;
        bannerY = imageLayer.getTextureRegion().getRegionHeight() + helvetique.getCapHeight()*1.5f;
        setBannerText(CLICK_AND_DRAG_MESSAGE);

        MapObject mapObject = mapObjects.get("0F");
        float gamepieceX = (float) mapObject.getProperties().get("x");
        float gamepieceY = (float) mapObject.getProperties().get("y");
        gamepiece = new Gamepiece(new int[]{0,0,-1,0,0,-1,0,1,1,1},0);
        graphicalGamepiece = new GraphicalGamepiece(gamepiece,blackSquare,gamepieceX,gamepieceY);

        Gdx.input.setInputProcessor(new MyEventHandler(this));
    }

    @Override
    public void render() {
        ScreenUtils.clear(1.0f, 1.0f, 1.0f, 1.0f);
        camera.setToOrtho(false,Gdx.graphics.getWidth(),Gdx.graphics.getHeight());
        camera.update();

        // first let's draw the tiled Map
        mapRenderer.setView(camera);
        mapRenderer.render();

        // Next we draw the gamepiece and the banner
        batch.begin();
        graphicalGamepiece.draw(batch);
        helvetique.draw(batch,bannerText,bannerX,bannerY);
        batch.end();
    }

    @Override
    public void dispose() {
        batch.dispose();
        skin.dispose();
        tiledMap.dispose();
    }

    public void setBannerText(String text) {
        bannerText = new String(text);
    }

    public Camera getCamera() {
        return camera;
    }

    public GraphicalGamepiece getGraphicalGamepiece() {
        return graphicalGamepiece;
    }
}
