import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.utils.ScreenUtils;

public class MyGame extends ApplicationAdapter {
    final static float SPEED = -80.0f; //20 world units per second (moving left)
    final static float START_X = 400.0f; // starting X coordinate
    final static float START_Y = 10.0f; // starting Y coordinate

    TextureAtlas atlas;
    TextureAtlas.AtlasRegion police;
    Sprite officer;
    SpriteBatch batch;
    OrthographicCamera camera;

    @Override
    public void create() {
        atlas = new TextureAtlas(Gdx.files.internal("sample.atlas"));
        police = atlas.findRegion("police");
        officer = new Sprite(police);
        officer.setPosition(START_X,START_Y);
        batch = new SpriteBatch();
        camera = new OrthographicCamera();
    }

    @Override
    public void render() {
        ScreenUtils.clear(1.0f, 1.0f, 1.0f, 1.0f);
        camera.setToOrtho(false,Gdx.graphics.getWidth(),Gdx.graphics.getHeight());
        camera.update();
        officer.translateX(SPEED * Gdx.graphics.getDeltaTime());
        if (officer.getX() < 0) {
            officer.setX(START_X);
        }
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        officer.draw(batch);
        batch.end();
    }

    @Override
    public void dispose() {
        batch.dispose();
        atlas.dispose();
    }
}
