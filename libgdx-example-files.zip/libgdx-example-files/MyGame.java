import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.utils.ScreenUtils;

public class MyGame extends ApplicationAdapter {

    @Override
    public void render() {
        ScreenUtils.clear(0f, 0f, 0.2f, 1.0f);
    }
}