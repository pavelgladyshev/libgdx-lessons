import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.ScreenUtils;

public class MyGame extends ApplicationAdapter {

    Texture square;
    SpriteBatch batch;
    OrthographicCamera camera;

    @Override
    public void create() {
        square = new Texture(Gdx.files.internal("game_square_black.png"));
        batch = new SpriteBatch();
        camera = new OrthographicCamera();
    }

    @Override
    public void render() {
        ScreenUtils.clear(1.0f, 1.0f, 1.0f, 1.0f);
        camera.setToOrtho(false,Gdx.graphics.getWidth(),Gdx.graphics.getHeight());
        camera.update();
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        batch.draw(square,10,10);
        batch.end();
        if (Gdx.input.isTouched()) {
            Vector3 screen = new Vector3(Gdx.input.getX(), Gdx.input.getY(),0);
            Vector3 world = camera.unproject(screen);
            System.out.printf("x=%f, y=%f\n", world.x, world.y);
        }
    }

    @Override
    public void dispose() {
        batch.dispose();
        square.dispose();
    }
}