import com.badlogic.gdx.InputAdapter;

public class MyEventHandler extends InputAdapter {

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        System.out.printf("touchDown event: x=%d, y=%d, pointer=%d, button=%d\n",  screenX, screenY, pointer, button);
        return true;
    }
}
