import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.MapLayer;
import com.badlogic.gdx.maps.MapObjects;
import com.badlogic.gdx.maps.MapProperties;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapImageLayer;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.utils.ScreenUtils;

public class MyGame extends ApplicationAdapter {

    final static int HEIGHT = 400;
    final static int WIDTH = 400;

    BitmapFont helvetique;
    SpriteBatch batch;
    TiledMap tiledMap;
    TiledMapImageLayer imageLayer;
    TiledMapTileLayer tileLayer;
    MapLayer objectLayer;
    MapObjects objects;
    float mapWidth;
    float mapHeight;
    MapProperties boardProp;
    Rectangle boardRect;
    OrthogonalTiledMapRenderer renderer;
    OrthographicCamera camera;

    @Override
    public void create() {
        helvetique = new BitmapFont(Gdx.files.internal("helvetique.fnt"));
        tiledMap = new TmxMapLoader().load("sample_map.tmx");
        imageLayer = (TiledMapImageLayer) tiledMap.getLayers().get("Image Layer"); // .get(0);
        tileLayer = (TiledMapTileLayer) tiledMap.getLayers().get("Tile Layer"); // .get(1);
        objectLayer = tiledMap.getLayers().get("Object Layer"); // .get(2);
        objects = objectLayer.getObjects();
        mapHeight = imageLayer.getTextureRegion().getRegionHeight();
        mapWidth = imageLayer.getTextureRegion().getRegionWidth();
        boardProp = objects.get("Board").getProperties();
        boardRect = new Rectangle(
                (float) boardProp.get("x"),
                (float) boardProp.get("y"),
                (float) boardProp.get("width"),
                (float) boardProp.get("height")
        );
        renderer = new OrthogonalTiledMapRenderer(tiledMap);
        batch = new SpriteBatch();
        camera = new OrthographicCamera();
    }

    @Override
    public void render() {
        ScreenUtils.clear(1.0f, 1.0f, 1.0f, 1.0f);

        camera.setToOrtho(false,Gdx.graphics.getWidth(),Gdx.graphics.getHeight());
        camera.translate(
                -(Gdx.graphics.getWidth()-mapWidth)*0.5f,
                -(Gdx.graphics.getHeight()-mapHeight)*0.5f
        );
        camera.update();
        renderer.setView(camera);
        renderer.render();
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        helvetique.draw(batch,"Hello :)",0,0);
        batch.end();
    }

    @Override
    public void dispose() {
        batch.dispose();
        helvetique.dispose();
        tiledMap.dispose();
    }
}
